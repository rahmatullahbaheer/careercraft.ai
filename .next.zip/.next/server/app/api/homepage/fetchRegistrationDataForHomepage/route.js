(()=>{var e={};e.id=4869,e.ids=[4869],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},32264:(e,t,a)=>{"use strict";a.r(t),a.d(t,{patchFetch:()=>f,routeModule:()=>m,serverHooks:()=>h,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>g});var r={};a.r(r),a.d(r,{POST:()=>p,dynamic:()=>u,maxDuration:()=>c});var s=a(96559),n=a(48088),i=a(37719),o=a(32190),d=a(40694);let c=300,u="force-dynamic";async function p(e){try{let t=await e.json();if(t){let e=t.content.substring(0,12e3);if(e){let t=new d.Ay({apiKey:process.env.OPENAI_API_KEY}),a=`
              This is the User Data:
              ${e}
    
              Now please give me the following information about the user:
              First Name:
              Last Name:
              Email Address:
              Phone Number:
              Industry: Select One Value from this array which is most suitable and put _id of that in industry attribute according to user's data [
                      {
                          "_id": "668fc655ffee5f179ca4a5a2",
                          "name": "Health Care",
                      },
                      {
                          "_id": "66a02d8931d56273c786852c",
                          "name": "Supply Chain/Logistics",
                      },
                      {
                          "_id": "66a02d9631d56273c786852d",
                          "name": "Corporate Development/Strategy",
                      },
                      {
                          "_id": "66a02da631d56273c786852e",
                          "name": "Research and Development (R&D)",
                      },
                      {
                          "_id": "66a02db431d56273c786852f",
                          "name": "Customer Service/Customer Experience",
                      },
                      {
                          "_id": "66a02dc531d56273c7868530",
                          "name": "Legal",
                      },
                      {
                          "_id": "66a02dd331d56273c7868531",
                          "name": "Product Management",
                      },
                      {
                          "_id": "66a02ddc31d56273c7868532",
                          "name": "Engineering",
                      },
                      {
                          "_id": "66a02de731d56273c7868533",
                          "name": "Sales",
                      },
                      {
                          "_id": "66a02df231d56273c7868534",
                          "name": "Human Resource",
                      },
                      {
                          "_id": "66a02dfc31d56273c7868535",
                          "name": "Operations",
                      },
                      {
                          "_id": "66a02e0431d56273c7868536",
                          "name": "Marketing",
                      },
                      {
                          "_id": "66a02e0d31d56273c7868537",
                          "name": "Finance",
                      },
                      {
                          "_id": "66a02e1431d56273c7868538",
                          "name": "Information Tecnology (IT)",
                      }                      
                  ]
    
    
              The answer MUST be a valid JSON and formatting should be like the following 
              replace the VALUE_HERE with the actual value
              {
                firstName: VALUE_HERE,
                lastName: VALUE_HERE,
                email: VALUE_HERE,
                registeredPhone: VALUE_HERE,
                industry: VALUE_HERE,                
              }
    
              If there is no value Leave that field blank
          `,r=await t.chat.completions.create({model:"gpt-4o-mini-2024-07-18",response_format:{type:"json_object"},messages:[{role:"user",content:a}],temperature:1,max_tokens:456});return o.NextResponse.json({success:!0,result:r.choices[0].message.content},{status:200})}}}catch(e){return o.NextResponse.json({result:"Something went wrong",success:!1},{status:404})}}let m=new s.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/homepage/fetchRegistrationDataForHomepage/route",pathname:"/api/homepage/fetchRegistrationDataForHomepage",filename:"route",bundlePath:"app/api/homepage/fetchRegistrationDataForHomepage/route"},resolvedPagePath:"F:\\RB-TECH\\Client Projects\\careercraft.ai\\src\\app\\api\\homepage\\fetchRegistrationDataForHomepage\\route.js",nextConfigOutput:"",userland:r}),{workAsyncStorage:l,workUnitAsyncStorage:g,serverHooks:h}=m;function f(){return(0,i.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:g})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[7719,580,694],()=>a(32264));module.exports=r})();