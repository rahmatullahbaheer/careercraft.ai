(()=>{var e={};e.id=7940,e.ids=[7940],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},5448:(e,t,r)=>{"use strict";r.d(t,{A:()=>o});var s=r(56037),i=r.n(s);let{Schema:a}=i(),n=new a({entryId:{type:String},type:{type:String,required:!0},input:{type:String,required:!0},output:{type:String,required:!0},idealOutput:{type:String},userEmail:String,fileAddress:String,Instructions:String,status:{type:String,enum:["pending","reviewed","trained"],required:!0}},{timestamps:!0}),o=i().models.TrainBot||i().model("TrainBot",n)},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14356:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>x,routeModule:()=>m,serverHooks:()=>E,workAsyncStorage:()=>b,workUnitAsyncStorage:()=>w});var s={};r.r(s),r.d(s,{POST:()=>f,dynamic:()=>l,maxDuration:()=>d});var i=r(96559),a=r(48088),n=r(37719),o=r(32190),p=r(40694),u=r(5448),c=r(83027),g=r(87967);let d=300,l="force-dynamic";async function f(e){try{let t=await e.json();if(t){let e=t.content.substring(0,13e3),r=t.trainBotData;if(e){let t=new p.Ay({apiKey:process.env.OPENAI_API_KEY});await (0,g.h)("register.wizard.listTrainings");let s=`
              This is the User Data:
              ${e}
    
              Now please give me a List of All Trainings found from the above user data provided.
    
              The answer MUST be a valid JSON and formatting should be like this 
              replace the VALUE_HERE with the actual values
              {
                trainings: [
                  {
                    company: VALUE_HERE,
                    position: VALUE_HERE,
                    startDate: VALUE_HERE,
                    endDate: VALUE_HERE,
                    description: array of strings,
                  },
                  .
                  .
                  .
                ]
              }
              If you don't see any Trainings just resturn empty like
              {
                trainings: []
              }
              If there is no value Leave that field blank
          `,i=await t.chat.completions.create({model:"gpt-4o-mini-2024-07-18",response_format:{type:"json_object"},messages:[{role:"user",content:s}]});try{if(r){await (0,c.A)();let e={type:"register.wizard.listTrainings",input:s,output:i?.choices[0]?.message?.content,idealOutput:"",status:"pending",userEmail:r?.userEmail,fileAddress:r?.fileAddress,Instructions:"Get List of all Trainings"};await u.A.create({...e})}}catch(e){return console.log(e),o.NextResponse.json({result:"Internal Server Error",success:!1},{status:404})}return o.NextResponse.json({success:!0,result:i.choices[0].message.content},{status:200})}}}catch(e){return o.NextResponse.json({result:"something went wrong",success:!1},{status:500})}}let m=new i.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/homepage/fetchTrainingsData/route",pathname:"/api/homepage/fetchTrainingsData",filename:"route",bundlePath:"app/api/homepage/fetchTrainingsData/route"},resolvedPagePath:"F:\\RB-TECH\\Client Projects\\careercraft.ai\\src\\app\\api\\homepage\\fetchTrainingsData\\route.js",nextConfigOutput:"",userland:s}),{workAsyncStorage:b,workUnitAsyncStorage:w,serverHooks:E}=m;function x(){return(0,n.patchFetch)({workAsyncStorage:b,workUnitAsyncStorage:w})}},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},56037:e=>{"use strict";e.exports=require("mongoose")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},83027:(e,t,r)=>{"use strict";let s;r.d(t,{A:()=>o});var i=r(56037),a=r.n(i);let n=process.env.MONGODB_URI,o=async()=>(s||(s=await a().connect(n)),s)},87967:(e,t,r)=>{"use strict";async function s(e){return({"register.wizard.listSkills":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icr9I31","register.wizard.listAwards":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listCertifications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listEducation":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listExperience":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listProjects":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listLanguages":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listHobbies":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listReferences":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listPublications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listRegistrations":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listTrainings":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.writeSummary":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE"})[e]||"gpt-4o-mini-2024-07-18"}r.d(t,{h:()=>s})},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[7719,580,694],()=>r(14356));module.exports=s})();