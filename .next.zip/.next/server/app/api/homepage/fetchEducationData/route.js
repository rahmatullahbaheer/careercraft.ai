(()=>{var e={};e.id=9139,e.ids=[9139],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},5448:(e,t,r)=>{"use strict";r.d(t,{A:()=>n});var a=r(56037),i=r.n(a);let{Schema:s}=i(),o=new s({entryId:{type:String},type:{type:String,required:!0},input:{type:String,required:!0},output:{type:String,required:!0},idealOutput:{type:String},userEmail:String,fileAddress:String,Instructions:String,status:{type:String,enum:["pending","reviewed","trained"],required:!0}},{timestamps:!0}),n=i().models.TrainBot||i().model("TrainBot",o)},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},56037:e=>{"use strict";e.exports=require("mongoose")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66909:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>y,routeModule:()=>E,serverHooks:()=>b,workAsyncStorage:()=>h,workUnitAsyncStorage:()=>m});var a={};r.r(a),r.d(a,{POST:()=>f,dynamic:()=>g,maxDuration:()=>l});var i=r(96559),s=r(48088),o=r(37719),n=r(32190),u=r(40694),c=r(5448),p=r(83027),d=r(87967);let l=300,g="force-dynamic";async function f(e){let t=await e.json();try{let e=t.content.substring(0,13e3),r=t.trainBotData;if(e){let t=new u.Ay({apiKey:process.env.OPENAI_API_KEY});await (0,d.h)("register.wizard.listEducation");let a=`
              This is the User Data:
              ${e}
    
              Now please give me a List of All Education(also include certifications, courses and other academic information if present) from the above user data provided.
    
              The answer MUST be a valid JSON and formatting should be like this 
              replace the VALUE_HERE with the actual values
              {
                education: [
                  {
                    educationLevel: VALUE_HERE,
                    fieldOfStudy: VALUE_HERE,
                    schoolName: VALUE_HERE,
                    schoolLocation: VALUE_HERE (Address of School which may include city and state/country),
                    fromMonth: VALUE_HERE (in full e.g. January, May),
                    fromYear: VALUE_HERE (in full e.g 2023, 1997),
                    toMonth: VALUE_HERE (in full e.g. January, May)
                    toYear: VALUE_HERE (in full e.g 2023, 1997),
                    isContinue: VALUE_HERE (Is Education continued? e.g true, false , if you don't see any detail than make it false),
                  },
                  .
                  .
                  .
                ]
              }
    
              if there is only one year or date fill it in the toYear and toMonth field
              If there is only Year and no month for an education record put the year in the toYear field and leave the toMonth field blank
              If there is no value Leave that field blank
              Months should be in full e.g. January, February, March, April, May, June, July, August, September, October, November, and December
          `,i=await t.chat.completions.create({model:"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE",messages:[{role:"user",content:a}],temperature:1});try{if(r){await (0,p.A)();let e={type:"register.wizard.listEducation",input:a,output:i?.choices[0]?.message?.content,idealOutput:"",status:"pending",userEmail:r?.userEmail,fileAddress:r?.fileAddress,Instructions:"Get List of all Education"};await c.A.create({...e})}}catch(e){}return n.NextResponse.json({success:!0,result:i.choices[0].message.content},{status:200})}}catch(e){return n.NextResponse.json({result:"something went wrong",success:!1},{status:500})}}let E=new i.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/homepage/fetchEducationData/route",pathname:"/api/homepage/fetchEducationData",filename:"route",bundlePath:"app/api/homepage/fetchEducationData/route"},resolvedPagePath:"F:\\RB-TECH\\Client Projects\\careercraft.ai\\src\\app\\api\\homepage\\fetchEducationData\\route.js",nextConfigOutput:"",userland:a}),{workAsyncStorage:h,workUnitAsyncStorage:m,serverHooks:b}=E;function y(){return(0,o.patchFetch)({workAsyncStorage:h,workUnitAsyncStorage:m})}},78335:()=>{},83027:(e,t,r)=>{"use strict";let a;r.d(t,{A:()=>n});var i=r(56037),s=r.n(i);let o=process.env.MONGODB_URI,n=async()=>(a||(a=await s().connect(o)),a)},87967:(e,t,r)=>{"use strict";async function a(e){return({"register.wizard.listSkills":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icr9I31","register.wizard.listAwards":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listCertifications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listEducation":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listExperience":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listProjects":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listLanguages":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listHobbies":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listReferences":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listPublications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listRegistrations":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listTrainings":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.writeSummary":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE"})[e]||"gpt-4o-mini-2024-07-18"}r.d(t,{h:()=>a})},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[7719,580,694],()=>r(66909));module.exports=a})();