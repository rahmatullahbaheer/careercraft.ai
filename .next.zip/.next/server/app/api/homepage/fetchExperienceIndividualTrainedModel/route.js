(()=>{var e={};e.id=9158,e.ids=[9158],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},5448:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});var n=r(56037),s=r.n(n);let{Schema:i}=s(),o=new i({entryId:{type:String},type:{type:String,required:!0},input:{type:String,required:!0},output:{type:String,required:!0},idealOutput:{type:String},userEmail:String,fileAddress:String,Instructions:String,status:{type:String,enum:["pending","reviewed","trained"],required:!0}},{timestamps:!0}),a=s().models.TrainBot||s().model("TrainBot",o)},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},36427:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>y,routeModule:()=>m,serverHooks:()=>E,workAsyncStorage:()=>g,workUnitAsyncStorage:()=>f});var n={};r.r(n),r.d(n,{POST:()=>h,dynamic:()=>l,maxDuration:()=>c});var s=r(96559),i=r(48088),o=r(37719),a=r(32190),u=r(40694),d=r(5448),p=r(83027);let c=300,l="force-dynamic";async function h(e){try{let t=await e.json();if(t){let e=t.content.substring(0,12e3),r=t.jobTitle,n=t.company,s=t.trainBotData;if(e){let t=new u.Ay({apiKey:process.env.OPENAI_API_KEY}),i=`
        This is the User Data:
            ${e}
            ___________________
  
            Now Find the details for  Job Title: ${r} at  ${n}  from the above provided User Data.
            and provide the following fields for that work experience:
            country, cityState, fromMonth, fromYear, isContinue, toMonth, toYear, description
            country: name of the country where this person worked in ${n}
            cityState:  name of the city or state where this person worked in ${n}
            fromMonth: means the month when this person started working at ${n} The month name must be in full e.g. Juanuary, February etc.
            fromYear: means the year when this person started working at ${n}
            toMonth: means the month when this person stopped working at ${n} The month name must be in full e.g. Juanuary, February etc.
            toYear: means the year when this person stopped working at ${n}
            isContinue: means if the person  is still working there or not (Is Experience continued? e.g true, false)
            description: fetch Work experience description of this person at ${n} from the User Data provided.
  
            The answer MUST be a valid JSON and formatting should be like this
            replace the VALUE_HERE with the actual values
            {
              country: VALUE_HERE,
              cityState: VALUE_HERE,
              fromMonth: VALUE_HERE,
              fromYear: VALUE_HERE,
              toMonth: VALUE_HERE,
              toYear: VALUE_HERE,
              isContinue: VALUE_HERE,
              description: VALUE_HERE
            }
  
            If there is no value for any field Leave that field blank e.g: ""  and do not add labels like "N/A", "Unknown" or "Not Available" etc.`,o=await t.chat.completions.create({model:"ft:gpt-3.5-turbo-0613:careerbooster-ai::8Dvh6dPq",messages:[{role:"user",content:i}],temperature:1});try{if(s){await (0,p.A)();let e={type:"register.wizard.individualExperience",input:i,output:o?.choices[0]?.message?.content,idealOutput:"",status:"pending",userEmail:s?.userEmail,fileAddress:s?.fileAddress,Instructions:`Find [[${r}]] at  [[${n}]]`};await d.A.create({...e})}}catch(e){return console.log(e),a.NextResponse.json({result:"Internal Server Error",success:!1},{status:404})}return a.NextResponse.json({success:!0,result:o.choices[0].message.content},{status:200})}}}catch(e){return a.NextResponse.json({result:"something went wrong",success:!1},{status:404})}}let m=new s.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/homepage/fetchExperienceIndividualTrainedModel/route",pathname:"/api/homepage/fetchExperienceIndividualTrainedModel",filename:"route",bundlePath:"app/api/homepage/fetchExperienceIndividualTrainedModel/route"},resolvedPagePath:"F:\\RB-TECH\\Client Projects\\careercraft.ai\\src\\app\\api\\homepage\\fetchExperienceIndividualTrainedModel\\route.js",nextConfigOutput:"",userland:n}),{workAsyncStorage:g,workUnitAsyncStorage:f,serverHooks:E}=m;function y(){return(0,o.patchFetch)({workAsyncStorage:g,workUnitAsyncStorage:f})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},56037:e=>{"use strict";e.exports=require("mongoose")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},83027:(e,t,r)=>{"use strict";let n;r.d(t,{A:()=>a});var s=r(56037),i=r.n(s);let o=process.env.MONGODB_URI,a=async()=>(n||(n=await i().connect(o)),n)},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[7719,580,694],()=>r(36427));module.exports=n})();