(()=>{var e={};e.id=7840,e.ids=[7840],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4422:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>w,routeModule:()=>E,serverHooks:()=>h,workAsyncStorage:()=>f,workUnitAsyncStorage:()=>b});var s={};r.r(s),r.d(s,{POST:()=>m,dynamic:()=>g,maxDuration:()=>l});var i=r(96559),a=r(48088),o=r(37719),n=r(32190),p=r(40694),c=r(5448),u=r(83027),d=r(87967);let l=300,g="force-dynamic";async function m(e){try{let t=await e.json();if(t){let e=t.content,r=t?.trainBotData;if(e){let t=new p.Ay({apiKey:process.env.OPENAI_API_KEY});await (0,d.h)("register.wizard.basicInfo");let s=`This is the User Data:
                ${e}
      
                Now please give me the following information about the user:
                First Name:
                Last Name:
                Email Address:
                Linkedin URL:
                Phone / Mobile Number:
                Country Name:
                Street Address:
                City or/and State Name:
                Postal Code from the provided data or get from the name of the City:
      
      
                The answer MUST be a valid JSON and formatting should be like this 
                replace the VALUE_HERE with the actual value
                {
                  firstName: VALUE_HERE,
                  lastName: VALUE_HERE,
                  email: VALUE_HERE,
                  linkedin: VALUE_HERE,
                  phone: VALUE_HERE,
                  country: VALUE_HERE,
                  street: VALUE_HERE,
                  cityState: VALUE_HERE,
                  postalCode: VALUE_HERE,
                }
      
                If there is no value Leave that field blank`,i=await t.chat.completions.create({model:"ft:gpt-3.5-turbo-1106:careerbooster-ai::8IKUVjUg",messages:[{role:"user",content:s}],temperature:1});try{if(r){await (0,u.A)();let e={type:"register.wizard.basicInfo",input:s,output:i?.choices[0]?.message?.content,idealOutput:"",status:"pending",userEmail:r?.userEmail,fileAddress:r?.fileAddress,Instructions:"Fetching basic information e.g. Name, email, phone, address, etc."};await c.A.create({...e})}}catch(e){return console.log(e),n.NextResponse.json({result:"Internal Server Error",success:!1},{status:404})}return n.NextResponse.json({result:i.choices[0].message.content,success:!0},{status:200})}}}catch(e){return n.NextResponse.json({result:"something went wrong",success:!1},{status:500})}}let E=new i.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/homepage/fetchRegistrationData/route",pathname:"/api/homepage/fetchRegistrationData",filename:"route",bundlePath:"app/api/homepage/fetchRegistrationData/route"},resolvedPagePath:"F:\\RB-TECH\\Client Projects\\careercraft.ai\\src\\app\\api\\homepage\\fetchRegistrationData\\route.js",nextConfigOutput:"",userland:s}),{workAsyncStorage:f,workUnitAsyncStorage:b,serverHooks:h}=E;function w(){return(0,o.patchFetch)({workAsyncStorage:f,workUnitAsyncStorage:b})}},5448:(e,t,r)=>{"use strict";r.d(t,{A:()=>n});var s=r(56037),i=r.n(s);let{Schema:a}=i(),o=new a({entryId:{type:String},type:{type:String,required:!0},input:{type:String,required:!0},output:{type:String,required:!0},idealOutput:{type:String},userEmail:String,fileAddress:String,Instructions:String,status:{type:String,enum:["pending","reviewed","trained"],required:!0}},{timestamps:!0}),n=i().models.TrainBot||i().model("TrainBot",o)},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},56037:e=>{"use strict";e.exports=require("mongoose")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},83027:(e,t,r)=>{"use strict";let s;r.d(t,{A:()=>n});var i=r(56037),a=r.n(i);let o=process.env.MONGODB_URI,n=async()=>(s||(s=await a().connect(o)),s)},87967:(e,t,r)=>{"use strict";async function s(e){return({"register.wizard.listSkills":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icr9I31","register.wizard.listAwards":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listCertifications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listEducation":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listExperience":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listProjects":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listLanguages":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listHobbies":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listReferences":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listPublications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listRegistrations":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listTrainings":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.writeSummary":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE"})[e]||"gpt-4o-mini-2024-07-18"}r.d(t,{h:()=>s})},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[7719,580,694],()=>r(4422));module.exports=s})();