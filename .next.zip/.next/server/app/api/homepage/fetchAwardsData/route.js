(()=>{var e={};e.id=529,e.ids=[529],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},5448:(e,t,r)=>{"use strict";r.d(t,{A:()=>n});var s=r(56037),a=r.n(s);let{Schema:i}=a(),o=new i({entryId:{type:String},type:{type:String,required:!0},input:{type:String,required:!0},output:{type:String,required:!0},idealOutput:{type:String},userEmail:String,fileAddress:String,Instructions:String,status:{type:String,enum:["pending","reviewed","trained"],required:!0}},{timestamps:!0}),n=a().models.TrainBot||a().model("TrainBot",o)},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},56037:e=>{"use strict";e.exports=require("mongoose")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},67332:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>x,routeModule:()=>f,serverHooks:()=>h,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>b});var s={};r.r(s),r.d(s,{POST:()=>w,dynamic:()=>g,maxDuration:()=>l});var a=r(96559),i=r(48088),o=r(37719),n=r(32190),p=r(40694),c=r(5448),u=r(83027),d=r(87967);let l=300,g="force-dynamic";async function w(e){try{let t=await e.json();if(t){let e=t.content.substring(0,13e3),r=t.trainBotData;if(e){let t=new p.Ay({apiKey:process.env.OPENAI_API_KEY});await (0,d.h)("register.wizard.listAwards");let s=`
              This is the User Data:
              ${e}
    
              Now please give me a List of All Scholarships and Awards found from the above user data provided.
    
              The answer MUST be a valid JSON and formatting should be like this 
              replace the VALUE_HERE with the actual values
              {
                awards: [
                  {
                    title: VALUE_HERE,
                    awardingOrganization: VALUE_HERE,
                    date: VALUE_HERE,
                    description: array of strings
                  },
                  .
                  .
                  .
                ]
              }
              If you don't see any Awards just return empty like
              {
                awards: []
              }
              If there is no value Leave that field blank
          `,a=await t.chat.completions.create({model:"gpt-4o-mini-2024-07-18",response_format:{type:"json_object"},messages:[{role:"user",content:s}]});try{if(r){await (0,u.A)();let e={type:"register.wizard.listAwards",input:s,output:a?.choices[0]?.message?.content,idealOutput:"",status:"pending",userEmail:r?.userEmail,fileAddress:r?.fileAddress,Instructions:"Get List of all Awards"};await c.A.create({...e})}}catch(e){}return n.NextResponse.json({success:!0,result:a.choices[0].message.content},{status:200})}}}catch(e){return n.NextResponse.json({result:"something went wrong",success:!1},{status:500})}}let f=new a.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/homepage/fetchAwardsData/route",pathname:"/api/homepage/fetchAwardsData",filename:"route",bundlePath:"app/api/homepage/fetchAwardsData/route"},resolvedPagePath:"F:\\RB-TECH\\Client Projects\\careercraft.ai\\src\\app\\api\\homepage\\fetchAwardsData\\route.js",nextConfigOutput:"",userland:s}),{workAsyncStorage:m,workUnitAsyncStorage:b,serverHooks:h}=f;function x(){return(0,o.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:b})}},78335:()=>{},83027:(e,t,r)=>{"use strict";let s;r.d(t,{A:()=>n});var a=r(56037),i=r.n(a);let o=process.env.MONGODB_URI,n=async()=>(s||(s=await i().connect(o)),s)},87967:(e,t,r)=>{"use strict";async function s(e){return({"register.wizard.listSkills":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icr9I31","register.wizard.listAwards":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listCertifications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listEducation":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listExperience":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listProjects":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listLanguages":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listHobbies":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listReferences":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listPublications":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listRegistrations":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.listTrainings":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE","register.wizard.writeSummary":"ft:gpt-3.5-turbo-1106:careerbooster-ai::8Icp5xpE"})[e]||"gpt-4o-mini-2024-07-18"}r.d(t,{h:()=>s})},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[7719,580,694],()=>r(67332));module.exports=s})();